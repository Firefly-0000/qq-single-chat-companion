from __future__ import annotations

import logging
import time
from datetime import datetime
from pathlib import Path

from PySide6.QtGui import QFont, QFontDatabase
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from ..config import AppSettings, SettingsStore
from ..domain import BotState, ChatMessage, TickResult
from ..service.orchestrator import Orchestrator
from ..service.runtime import Runtime, TargetBindingError
from .worker import EngineWorker

logger = logging.getLogger(__name__)


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("QQ 单会话陪聊助手")
        self.resize(1120, 760)
        self.settings_store = SettingsStore()
        self.settings = self.settings_store.load()
        self.runtime = Runtime.create(self.settings)
        self.orchestrator = Orchestrator(
            settings=self.settings,
            storage=self.runtime.storage,
            detector=self.runtime.detector,
            generator=self.runtime.generator,
            sender=self.runtime.sender,
        )
        self.worker: EngineWorker | None = None
        self.bound_window = None
        self._build_ui()
        self._load_settings_into_ui()
        self._append_log("程序已启动。请先打开目标私聊并完成绑定。")

    def _build_ui(self) -> None:
        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_control_tab(), "控制")
        self.tabs.addTab(self._build_conversation_tab(), "对话")
        self.tabs.addTab(self._build_settings_tab(), "设置")
        self.setCentralWidget(self.tabs)
        self.statusBar().showMessage("未绑定")

    def _build_control_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)

        bind_row = QHBoxLayout()
        bind_row.addWidget(QLabel("目标用户名称"))
        self.target_name_input = QLineEdit()
        self.target_name_input.setPlaceholderText("输入 QQ 当前显示的昵称或备注名")
        self.target_name_input.textChanged.connect(self._update_bind_button_state)
        bind_row.addWidget(self.target_name_input, stretch=1)
        self.bind_button = QPushButton("绑定当前对话")
        self.bind_button.clicked.connect(self._bind_current_chat)
        bind_row.addWidget(self.bind_button)
        layout.addLayout(bind_row)

        control_row = QHBoxLayout()
        self.start_button = QPushButton("开始")
        self.pause_button = QPushButton("暂停")
        self.stop_button = QPushButton("停止")
        self.emergency_button = QPushButton("急停")
        self.start_button.clicked.connect(self._start)
        self.pause_button.clicked.connect(self._pause)
        self.stop_button.clicked.connect(self._stop)
        self.emergency_button.clicked.connect(self._emergency_stop)
        for button in (
            self.start_button,
            self.pause_button,
            self.stop_button,
            self.emergency_button,
        ):
            control_row.addWidget(button)
        control_row.addStretch(1)
        self.auto_send_checkbox = QCheckBox("启用自动发送")
        self.auto_send_checkbox.toggled.connect(self._toggle_auto_send)
        control_row.addWidget(self.auto_send_checkbox)
        layout.addLayout(control_row)

        separator = QFrame()
        separator.setFrameShape(QFrame.Shape.HLine)
        separator.setFrameShadow(QFrame.Shadow.Sunken)
        layout.addWidget(separator)

        state_row = QHBoxLayout()
        state_row.addWidget(QLabel("状态"))
        self.state_label = QLabel(BotState.UNBOUND.value)
        self.state_label.setObjectName("stateLabel")
        state_row.addWidget(self.state_label)
        state_row.addStretch(1)
        layout.addLayout(state_row)

        self.event_label = QLabel("暂无事件")
        self.event_label.setWordWrap(True)
        layout.addWidget(self.event_label)

        layout.addWidget(QLabel("运行日志"))
        self.log_output = QPlainTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setMaximumBlockCount(1000)
        layout.addWidget(self.log_output, stretch=1)
        return page

    def _build_conversation_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(20, 20, 20, 20)

        toolbar = QHBoxLayout()
        refresh_button = QPushButton("刷新")
        refresh_button.clicked.connect(self._refresh_context)
        clear_button = QPushButton("清空上下文")
        clear_button.clicked.connect(self._clear_context)
        save_context_button = QPushButton("保存上下文")
        save_context_button.clicked.connect(self._save_context)
        toolbar.addWidget(refresh_button)
        toolbar.addWidget(clear_button)
        toolbar.addWidget(save_context_button)
        toolbar.addStretch(1)
        layout.addLayout(toolbar)

        self.context_output = QPlainTextEdit()
        self.context_output.setReadOnly(False)
        layout.addWidget(self.context_output, stretch=1)
        return page

    def _build_settings_tab(self) -> QWidget:
        page = QWidget()
        outer = QVBoxLayout(page)
        outer.setContentsMargins(20, 20, 20, 20)

        form = QFormLayout()
        self.api_key_input = QLineEdit()
        self.api_key_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.base_url_input = QLineEdit()
        self.model_input = QLineEdit()
        self.poll_interval_input = QSpinBox()
        self.poll_interval_input.setRange(250, 10_000)
        self.poll_interval_input.setSuffix(" ms")
        self.timeout_input = QSpinBox()
        self.timeout_input.setRange(5, 300)
        self.timeout_input.setSuffix(" 秒")
        self.max_reply_input = QSpinBox()
        self.max_reply_input.setRange(10, 5_000)
        self.max_reply_input.setSuffix(" 字")
        self.persona_name_input = QLineEdit()
        self.relationship_input = QLineEdit()
        self.tone_input = QLineEdit()
        self.forbidden_topics_input = QLineEdit()

        form.addRow("DeepSeek API Key", self.api_key_input)
        form.addRow("Base URL", self.base_url_input)
        form.addRow("模型", self.model_input)
        form.addRow("检测间隔", self.poll_interval_input)
        form.addRow("请求超时", self.timeout_input)
        form.addRow("最大回复长度", self.max_reply_input)
        form.addRow("人设称呼", self.persona_name_input)
        form.addRow("双方关系", self.relationship_input)
        form.addRow("回复语气", self.tone_input)
        form.addRow("禁止词", self.forbidden_topics_input)
        outer.addLayout(form)

        buttons = QHBoxLayout()
        save_button = QPushButton("保存设置")
        save_button.clicked.connect(self._save_settings)
        buttons.addWidget(save_button)
        buttons.addStretch(1)
        outer.addLayout(buttons)
        outer.addStretch(1)
        return page

    def _load_settings_into_ui(self) -> None:
        self.target_name_input.setText(self.settings.target_user_name)
        self.api_key_input.setText(self.settings.api_key)
        self.base_url_input.setText(self.settings.api_base_url)
        self.model_input.setText(self.settings.model)
        self.poll_interval_input.setValue(self.settings.poll_interval_ms)
        self.timeout_input.setValue(self.settings.request_timeout_seconds)
        self.max_reply_input.setValue(self.settings.max_reply_chars)
        self.persona_name_input.setText(self.settings.persona.display_name)
        self.relationship_input.setText(self.settings.persona.relationship)
        self.tone_input.setText(self.settings.persona.tone)
        self.forbidden_topics_input.setText("，".join(self.settings.persona.forbidden_topics))
        self.auto_send_checkbox.setChecked(self.settings.auto_send)
        self._update_bind_button_state()

    def _collect_settings(self) -> AppSettings:
        forbidden = [
            item.strip()
            for item in self.forbidden_topics_input.text().replace(",", "，").split("，")
            if item.strip()
        ]
        return self.settings.model_copy(
            update={
                "target_user_name": self.target_name_input.text().strip(),
                "api_key": self.api_key_input.text(),
                "api_base_url": self.base_url_input.text().strip(),
                "model": self.model_input.text().strip(),
                "poll_interval_ms": self.poll_interval_input.value(),
                "request_timeout_seconds": self.timeout_input.value(),
                "max_reply_chars": self.max_reply_input.value(),
                "auto_send": self.auto_send_checkbox.isChecked(),
                "persona": self.settings.persona.model_copy(
                    update={
                        "display_name": self.persona_name_input.text().strip(),
                        "relationship": self.relationship_input.text().strip()
                        or self.settings.persona.relationship,
                        "tone": self.tone_input.text().strip() or self.settings.persona.tone,
                        "forbidden_topics": forbidden,
                    }
                ),
            }
        )

    def _bind_current_chat(self) -> None:
        try:
            settings = self._collect_settings()
            if not settings.target_user_name:
                raise TargetBindingError("请输入目标用户名称")
            self.settings = settings
            self.runtime.update_settings(settings)
            self.bound_window = self.runtime.bind_target(settings.target_user_name)
            self.orchestrator.settings = settings
            self.orchestrator.bind(self.bound_window)
            self._set_state(BotState.READY)
            self._append_log(f"已绑定：{self.bound_window.title}")
            self.settings_store.save(settings)
            self._refresh_context()
        except Exception as exc:
            self._show_error("绑定失败", str(exc))
            self._set_state(BotState.UNBOUND)

    def _start(self) -> None:
        try:
            settings = self._collect_settings()
            self.settings = settings
            self.runtime.update_settings(settings)
            self.orchestrator.settings = settings
            if self.bound_window is not None:
                self.runtime.window_provider.focus(self.bound_window.handle)
            self.orchestrator.start()
            if self.worker is None or not self.worker.isRunning():
                self.worker = EngineWorker(self.orchestrator, settings.poll_interval_ms)
                self.worker.result_ready.connect(self._handle_tick_result)
                self.worker.failed.connect(self._handle_worker_error)
                self.worker.start()
            self._set_state(self.orchestrator.state)
            self._append_log("开始监测。")
        except Exception as exc:
            self._show_error("启动失败", str(exc))

    def _pause(self) -> None:
        self.orchestrator.pause()
        self._set_state(self.orchestrator.state)
        self._append_log("已暂停。")

    def _stop(self) -> None:
        self.orchestrator.stop()
        self._stop_worker()
        self._set_state(self.orchestrator.state)
        self._append_log("已停止。")

    def _emergency_stop(self) -> None:
        self.orchestrator.emergency_stop()
        self.auto_send_checkbox.setChecked(False)
        self._stop_worker()
        self._set_state(self.orchestrator.state)
        self._append_log("急停：自动发送已关闭。")

    def _stop_worker(self) -> None:
        if self.worker is None:
            return
        self.worker.request_stop()
        self.worker.wait(3000)
        self.worker = None

    def _toggle_auto_send(self, enabled: bool) -> None:
        self.settings.auto_send = enabled
        self.orchestrator.settings.auto_send = enabled
        self._append_log("自动发送已开启。" if enabled else "自动发送已关闭。")

    def _save_settings(self) -> None:
        try:
            settings = self._collect_settings()
            self.settings = settings
            self.runtime.update_settings(settings)
            self.orchestrator.settings = settings
            self.settings_store.save(settings)
            self._append_log("设置已保存。")
        except Exception as exc:
            self._show_error("保存失败", str(exc))

    def _handle_tick_result(self, result: TickResult) -> None:
        self._set_state(result.state)
        if result.message:
            self._append_log(result.message)
        if result.event is not None:
            self.event_label.setText(
                f"{datetime.now():%H:%M:%S}  {result.kind.value}: "
                f"{result.event.text[:160]}"
            )
        if result.reply is not None:
            self._append_log(f"回复草稿：{result.reply}")
        if result.context:
            self._render_context(result.context)

    def _handle_worker_error(self, message: str) -> None:
        self._show_error("运行错误", message)

    def _refresh_context(self) -> None:
        messages = self.runtime.storage.recent_messages(self.settings.context_recent_messages)
        self._render_context(messages)

    def _render_context(self, messages: list[object]) -> None:
        lines: list[str] = []
        for message in messages:
            role = getattr(message, "role", "unknown")
            text = getattr(message, "text", "")
            label = {"user": "对方", "assistant": "回复"}.get(role, role)
            lines.append(f"{label}: {text}")
        self.context_output.setPlainText("\n".join(lines))

    def _save_context(self) -> None:
        messages = []
        now = time.time()
        for index, raw_line in enumerate(self.context_output.toPlainText().splitlines()):
            line = raw_line.strip()
            if not line:
                continue
            if line.startswith("对方:"):
                role = "user"
                text = line.removeprefix("对方:").strip()
            elif line.startswith("回复:"):
                role = "assistant"
                text = line.removeprefix("回复:").strip()
            else:
                self._show_error("上下文格式错误", f"无法识别行：{line}")
                return
            messages.append(
                ChatMessage(
                    role=role,
                    text=text,
                    source="manual",
                    confidence=None,
                    timestamp=now + index,
                )
            )
        self.runtime.storage.replace_messages(messages)
        self._append_log("上下文已更新。")
        self._refresh_context()

    def _clear_context(self) -> None:
        answer = QMessageBox.question(
            self,
            "清空上下文",
            "确认清空当前对话上下文？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer == QMessageBox.StandardButton.Yes:
            self.runtime.storage.clear_messages()
            self.runtime.storage.set_state("context_cleared_at", datetime.now().isoformat())
            self._refresh_context()
            self._append_log("上下文已清空。")

    def _set_state(self, state: BotState) -> None:
        self.state_label.setText(state.value)
        self.statusBar().showMessage(state.value)
        running = state in {
            BotState.READY,
            BotState.MONITORING,
            BotState.GENERATING,
            BotState.SENDING,
        }
        self.bind_button.setEnabled(
            not running and bool(self.target_name_input.text().strip())
        )
        self.start_button.setEnabled(
            state in {BotState.READY, BotState.PAUSED, BotState.STOPPED}
            and self.bound_window is not None
        )
        self.pause_button.setEnabled(
            state in {BotState.MONITORING, BotState.GENERATING, BotState.SENDING}
        )

    def _update_bind_button_state(self) -> None:
        if not hasattr(self, "bind_button"):
            return
        running = self.orchestrator.state in {
            BotState.READY,
            BotState.MONITORING,
            BotState.GENERATING,
            BotState.SENDING,
        }
        self.bind_button.setEnabled(
            bool(self.target_name_input.text().strip()) and not running
        )

    def _append_log(self, message: str) -> None:
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_output.appendPlainText(f"[{timestamp}] {message}")

    def _show_error(self, title: str, message: str) -> None:
        self._append_log(f"{title}: {message}")
        QMessageBox.critical(self, title, message)

    def closeEvent(self, event: object) -> None:
        self._stop_worker()
        event.accept()


def run_gui() -> int:
    app = QApplication.instance() or QApplication([])
    _configure_font(app)
    window = MainWindow()
    window.show()
    return app.exec()


def _configure_font(app: QApplication) -> None:
    for candidate in (
        Path("C:/Windows/Fonts/msyh.ttc"),
        Path("C:/Windows/Fonts/msyh.ttf"),
    ):
        if not candidate.exists():
            continue
        font_id = QFontDatabase.addApplicationFont(str(candidate))
        families = QFontDatabase.applicationFontFamilies(font_id)
        if families:
            app.setFont(QFont(families[0], 10))
            return
    app.setFont(QFont("Microsoft YaHei UI", 10))
