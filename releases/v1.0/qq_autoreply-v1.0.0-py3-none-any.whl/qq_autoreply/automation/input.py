from __future__ import annotations

import logging
import time

from ..config import AppSettings
from ..domain import WindowRect
from ..vision.capture import MssCapture
from ..vision.detector import MessageDetector, normalize_text
from ..vision.ocr import RapidOcrEngine
from ..vision.windows import Win32WindowProvider

logger = logging.getLogger(__name__)


class SendError(RuntimeError):
    pass


class InputVerificationError(SendError):
    pass


class SendUncertainError(SendError):
    pass


class DesktopReplySender:
    def __init__(
        self,
        *,
        settings: AppSettings,
        detector: MessageDetector,
        capture: MssCapture,
        ocr: RapidOcrEngine,
        window_provider: Win32WindowProvider,
    ) -> None:
        self.settings = settings
        self.detector = detector
        self.capture = capture
        self.ocr = ocr
        self.window_provider = window_provider

    def send(self, text: str) -> None:
        if self.detector.window is None or self.detector.layout is None:
            raise SendError("No bound QQ window")
        if not text.strip():
            raise SendError("Refusing to send empty text")

        import pyautogui
        import pyperclip

        validation = self.detector.validate_target()
        if validation is not None:
            raise SendError(validation.reason or "Target validation failed")

        window = self.detector.window
        layout = self.detector.layout
        self.window_provider.focus(window.handle)
        pyautogui.click(*layout.input_click)

        previous_clipboard = ""
        try:
            previous_clipboard = pyperclip.paste()
        except Exception:
            previous_clipboard = ""

        try:
            pyperclip.copy(text)
            pyautogui.hotkey("ctrl", "v")
            time.sleep(0.25)
            input_frame = self.capture.capture(layout.input)
            input_lines = self.ocr.recognize(input_frame)
            observed = normalize_text(" ".join(line.text for line in input_lines))
            if normalize_text(text) not in observed:
                raise InputVerificationError("Input text verification failed")

            pyautogui.press("enter")
            if not self._verify_sent(text, layout.messages):
                raise SendUncertainError("Could not confirm outgoing message")
        finally:
            try:
                pyperclip.copy(previous_clipboard)
            except Exception:
                logger.debug("Clipboard restore failed", exc_info=True)

    def _verify_sent(self, text: str, message_rect: WindowRect) -> bool:
        expected = normalize_text(text)
        deadline = time.monotonic() + 5.0
        while time.monotonic() < deadline:
            frame = self.capture.capture(message_rect)
            lines = self.ocr.recognize(frame)
            for line in lines:
                if line.center_x < message_rect.width * 0.55:
                    continue
                observed = normalize_text(line.text)
                if expected and (expected in observed or observed in expected):
                    return True
            time.sleep(0.25)
        return False


class FakeReplySender:
    def __init__(self) -> None:
        self.sent: list[str] = []

    def send(self, text: str) -> None:
        self.sent.append(text)
