from __future__ import annotations

from types import SimpleNamespace

import pytest

from qq_autoreply.config import AppSettings
from qq_autoreply.deepseek import DeepSeekReplyGenerator, GenerationError
from qq_autoreply.domain import ChatMessage


class FakeCompletions:
    def create(self, **_: object) -> object:
        return SimpleNamespace(
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(content="这是一条测试回复")
                )
            ]
        )


class FakeClient:
    chat = SimpleNamespace(completions=FakeCompletions())


def test_missing_api_key_raises() -> None:
    generator = DeepSeekReplyGenerator(AppSettings(api_key=""))

    with pytest.raises(GenerationError):
        generator.generate([])


def test_generate_returns_text() -> None:
    generator = DeepSeekReplyGenerator(AppSettings(api_key="sk-test"))
    generator._client = FakeClient()  # type: ignore[assignment]

    reply = generator.generate(
        [ChatMessage(role="user", text="你好", source="ocr", timestamp=1.0)]
    )

    assert reply == "这是一条测试回复"
