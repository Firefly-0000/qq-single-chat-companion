from __future__ import annotations

from PySide6.QtWidgets import QApplication

from qq_autoreply.ui.main_window import MainWindow


def test_main_window_contains_target_name_input() -> None:
    app = QApplication.instance() or QApplication([])
    window = MainWindow()

    assert window.target_name_input is not None
    assert window.bind_button.text() == "绑定当前对话"
    assert window.bind_button.isEnabled() is False

    window.target_name_input.setText("张三")
    assert window.bind_button.isEnabled() is True

    window.close()
    app.processEvents()
