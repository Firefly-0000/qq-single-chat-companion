"""Single-conversation QQ companion assistant."""

__all__ = ["__version__"]

__version__ = "2.0.0"
