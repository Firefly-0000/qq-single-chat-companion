"""Desktop input automation."""
