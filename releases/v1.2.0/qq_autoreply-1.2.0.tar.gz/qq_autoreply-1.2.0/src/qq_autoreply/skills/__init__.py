"""Bundled skills."""
